package io.github.romanvht.byedpi.utility

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.services.ServiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.Inet4Address

/**
 * Шаг 3: запоминает, какая стратегия сработала в какой сети (дом, мобильный интернет, чужой Wi-Fi),
 * и при смене сети сама включает сохранённую. Сеть определяется без разрешения на геолокацию:
 * для мобильной — по оператору, для Wi-Fi/Ethernet — по отпечатку шлюза, подсети и DNS (хэш).
 */
object NetworkMemory {
    private const val TAG = "NetworkMemory"
    const val KEY = "network_memory_enabled"
    private const val STORE = "network_strategies"
    private const val MAX_NETWORKS = 20

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var callback: ConnectivityManager.NetworkCallback? = null
    private var pending: Job? = null
    @Volatile private var lastKey: String? = null
    @Volatile private var mode: Mode = Mode.VPN

    /** Ключ текущей физической сети (VPN самого приложения пропускается). */
    @Suppress("DEPRECATION")
    fun currentKey(ctx: Context): String? {
        val cm = ContextCompat.getSystemService(ctx, ConnectivityManager::class.java) ?: return null
        val nets = cm.allNetworks.mapNotNull { n ->
            val caps = cm.getNetworkCapabilities(n) ?: return@mapNotNull null
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) return@mapNotNull null
            Triple(n, caps, caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))
        }
        val (net, caps, _) = nets.firstOrNull { it.third } ?: nets.firstOrNull() ?: return null

        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            val op = ContextCompat.getSystemService(ctx, TelephonyManager::class.java)?.networkOperator
            return "mobile:" + (if (op.isNullOrBlank()) "unknown" else op)
        }
        val lp = cm.getLinkProperties(net) ?: return null
        val gateway = lp.routes.firstOrNull { it.isDefaultRoute && it.hasGateway() }?.gateway?.hostAddress
        val subnet = lp.linkAddresses.firstOrNull { it.address is Inet4Address }
            ?.let { it.address.hostAddress?.substringBeforeLast('.') + "/" + it.prefixLength }
        val dns = lp.dnsServers.mapNotNull { it.hostAddress }.sorted().joinToString(",")
        val kind = if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) "wifi" else "net"
        return kind + ":" + "$gateway|$subnet|$dns".hashCode().toString(16)
    }

    private fun load(prefs: android.content.SharedPreferences): LinkedHashMap<String, String> {
        val json = prefs.getString(STORE, null) ?: return LinkedHashMap()
        return try {
            Gson().fromJson<LinkedHashMap<String, String>>(json, object : TypeToken<LinkedHashMap<String, String>>() {}.type)
                ?: LinkedHashMap()
        } catch (e: Exception) {
            LinkedHashMap()
        }
    }

    /** Запоминает, что команда [cmd] сейчас работает в текущей сети. */
    fun remember(ctx: Context, cmd: String) {
        val prefs = ctx.getPreferences()
        if (!prefs.getBoolean(KEY, true) || !prefs.getCmdEnable()) return
        val key = currentKey(ctx) ?: return
        val map = load(prefs)
        if (map[key] == cmd) return
        map.remove(key)
        map[key] = cmd
        while (map.size > MAX_NETWORKS) map.remove(map.keys.first())
        prefs.edit { putString(STORE, Gson().toJson(map)) }
        Log.i(TAG, "запомнена стратегия для сети $key")
    }

    @Synchronized
    fun start(app: Application, mode: Mode) {
        this.mode = mode
        if (callback != null) return
        val cm = ContextCompat.getSystemService(app, ConnectivityManager::class.java) ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = onNetworkChanged(app)
        }
        try {
            cm.registerNetworkCallback(request, cb)
            callback = cb
        } catch (e: Exception) {
            Log.e(TAG, "не удалось подписаться на смену сети", e)
        }
    }

    @Synchronized
    fun stop(app: Application) {
        callback?.let {
            try { ContextCompat.getSystemService(app, ConnectivityManager::class.java)?.unregisterNetworkCallback(it) }
            catch (_: Exception) { }
        }
        callback = null
        pending?.cancel()
        pending = null
    }

    private fun onNetworkChanged(app: Application) {
        pending?.cancel()
        pending = scope.launch {
            delay(3_000) // даём сети «устояться»
            val prefs = app.getPreferences()
            if (!prefs.getBoolean(KEY, true) || !prefs.getCmdEnable()) return@launch
            val key = currentKey(app) ?: return@launch
            if (key == lastKey) return@launch
            lastKey = key
            val saved = load(prefs)[key] ?: return@launch
            if (saved == prefs.getCmdArgs()) return@launch
            prefs.edit { putString("byedpi_cmd_args", saved) }
            withContext(Dispatchers.Main) { ServiceManager.restart(app, mode) }
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(app, R.string.network_memory_applied, Toast.LENGTH_LONG).show()
            }
        }
    }
}
