package io.github.romanvht.byedpi.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Эффекты вокруг кнопки-ядра: в покое — мерцающее пунктирное кольцо,
 * при подключении — волны, кометы по орбите и вспышка искр.
 */
class VoidFxView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Spark(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var life: Float, val maxLife: Float, val size: Float
    )

    private val d = resources.displayMetrics.density
    private val rnd = Random(5)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sparks = ArrayList<Spark>()
    private val ripples = ArrayList<Float>()

    private var t = 0f
    private var lastNs = 0L
    private var mix = 0f
    private var active = false
    private var lastRipple = -10f

    private val violet = 0xFF8D68ED.toInt()
    private val blue = 0xFF408DE5.toInt()
    private val mint = 0xFF1FD6A5.toInt()
    private val cyan = 0xFF3FD0F0.toInt()

    fun setActive(a: Boolean) {
        active = a
    }

    /** Одна волна (при нажатии). */
    fun ping() {
        ripples.add(t)
    }

    /** Вспышка при подключении: две волны и россыпь искр. */
    fun burst() {
        ripples.add(t)
        ripples.add(t + 0.25f)
        repeat(40) {
            val ang = rnd.nextFloat() * 2f * PI.toFloat()
            val sp = (80f + rnd.nextFloat() * 190f) * d
            val life = 0.9f + rnd.nextFloat() * 0.8f
            sparks.add(Spark(0f, 0f, cos(ang) * sp, sin(ang) * sp, life, life, (1.2f + rnd.nextFloat() * 2.4f) * d))
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastNs = 0L
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min((now - lastNs) / 1_000_000_000f, 0.05f)
        lastNs = now
        t += dt
        mix += ((if (active) 1f else 0f) - mix) * min(1f, dt * 3f)

        val cx = width / 2f
        val cy = height / 2f
        val twoPi = 2f * PI.toFloat()

        // 1) пунктирное кольцо в покое
        val idle = 1f - mix
        if (idle > 0.02f) {
            val n = 48
            val ringR = 119f * d
            for (i in 0 until n) {
                val ang = t * 0.18f + i * twoPi / n
                val tw = 0.5f + 0.5f * sin(t * 1.6f + i * 0.7f)
                paint.color = ColorUtils.blendARGB(violet, blue, i / (n - 1f))
                paint.alpha = (255 * idle * (0.12f + 0.45f * tw)).toInt().coerceIn(0, 255)
                c.drawCircle(cx + cos(ang) * ringR, cy + sin(ang) * ringR, (1.2f + 1.0f * tw) * d, paint)
            }
        }

        // 2) расходящиеся волны
        if (active && t - lastRipple > 1.3f) {
            ripples.add(t)
            lastRipple = t
        }
        val life = 2.4f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * d
        val it = ripples.iterator()
        while (it.hasNext()) {
            val age = t - it.next()
            if (age > life) { it.remove(); continue }
            if (age < 0f) continue
            val k = age / life
            val r = (86f + 42f * (1f - (1f - k) * (1f - k))) * d
            paint.color = ColorUtils.blendARGB(mint, cyan, k)
            paint.alpha = (255 * 0.55f * (1f - k) * (1f - k)).toInt().coerceIn(0, 255)
            c.drawCircle(cx, cy, r, paint)
        }
        paint.style = Paint.Style.FILL

        // 3) кометы по орбите
        if (mix > 0.02f) {
            comet(c, cx, cy, 108f * d, t * 1.25f, 1f)
            comet(c, cx, cy, 108f * d, t * 1.25f + PI.toFloat(), 1f)
            comet(c, cx, cy, 119f * d, -t * 0.8f + 1f, -1f)
        }

        // 4) искры
        val si = sparks.iterator()
        val friction = Math.pow(0.96, (dt * 60f).toDouble()).toFloat()
        while (si.hasNext()) {
            val s = si.next()
            s.life -= dt
            if (s.life <= 0f) { si.remove(); continue }
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.vx *= friction
            s.vy *= friction
            val f = s.life / s.maxLife
            paint.color = ColorUtils.blendARGB(cyan, mint, f)
            paint.alpha = (255 * f).toInt().coerceIn(0, 255)
            c.drawCircle(cx + s.x, cy + s.y, s.size * (0.4f + 0.6f * f), paint)
        }

        postInvalidateOnAnimation()
    }

    private fun comet(c: Canvas, cx: Float, cy: Float, r: Float, head: Float, dir: Float) {
        val steps = 16
        for (k in steps downTo 0) {
            val ang = head - dir * k * 0.05f
            val frac = 1f - k / steps.toFloat()
            paint.color = ColorUtils.blendARGB(cyan, mint, frac)
            paint.alpha = (255 * mix * frac * frac * 0.9f).toInt().coerceIn(0, 255)
            c.drawCircle(cx + cos(ang) * r, cy + sin(ang) * r, (1f + 4.2f * frac) * d, paint)
        }
        val hx = cx + cos(head) * r
        val hy = cy + sin(head) * r
        paint.color = mint
        paint.alpha = (255 * mix * 0.18f).toInt()
        c.drawCircle(hx, hy, 15f * d, paint)
        paint.alpha = (255 * mix * 0.35f).toInt()
        c.drawCircle(hx, hy, 9f * d, paint)
        paint.color = 0xFFFFFFFF.toInt()
        paint.alpha = (255 * mix).toInt()
        c.drawCircle(hx, hy, 3.6f * d, paint)
    }
}
